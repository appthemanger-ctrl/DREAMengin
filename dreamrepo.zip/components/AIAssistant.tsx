'use client';

import { useState, useRef, useEffect } from 'react';
import { Bot, Send, X, Minimize2, Maximize2 } from 'lucide-react';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

export default function AIAssistant() {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content: 'Hello! I\'m Dr. Eams, your personal guide to DREAMengin. I\'m here to help you navigate the platform, manage your content, discover features, and make the most of your creative journey. What would you like to explore today?',
      timestamp: new Date()
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    // Simulate AI response - in production, this would call your AI API
    setTimeout(() => {
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: getSmartResponse(input),
        timestamp: new Date()
      };
      setMessages(prev => [...prev, aiMessage]);
      setIsLoading(false);
    }, 1000);
  };

  const getSmartResponse = (query: string): string => {
    const lowerQuery = query.toLowerCase();
    
    if (lowerQuery.includes('post') || lowerQuery.includes('create')) {
      return 'Great question! To create a post, simply click the "+ Create" button in the navigation bar, or you can press Ctrl+P for quick access. You can add text, images, and tags to make your posts engaging. Would you like me to walk you through the posting process step by step?';
    } else if (lowerQuery.includes('profile')) {
      return 'Your profile is your creative hub on DREAMengin! Navigate to Settings → Edit Profile to customize everything about your presence. You can update your bio, change your avatar, select a theme, showcase your music, display merchandise, and highlight your lab projects. Think of it as your personal portfolio that tells your story!';
    } else if (lowerQuery.includes('ad') || lowerQuery.includes('monetize')) {
      return 'Monetization is one of the most powerful features here! The Ad Marketplace lets you create ad slots on your profile and set your own pricing. You manage bookings, track performance, and revenue sharing is built right in. Head to the Ads page to get started. Many creators find this to be a great passive income stream!';
    } else if (lowerQuery.includes('lab') || lowerQuery.includes('science')) {
      return 'The Lab is where science meets collaboration! You can create projects with markdown notebooks, attach research files, embed interactive physics simulations, and invite other researchers to collaborate. It\'s like having your own research journal that\'s also a social platform. Perfect for documenting experiments and sharing discoveries!';
    } else if (lowerQuery.includes('feed') || lowerQuery.includes('dashboard')) {
      return 'Your dashboard is fully customizable to fit your workflow! You can drag and drop widgets to rearrange them however you like. Add widgets for notifications, promotions, quick stats, analytics, and more. Try clicking and dragging one of your widgets now to see how easy it is to personalize your experience!';
    } else if (lowerQuery.includes('music')) {
      return 'Music is a first-class citizen on DREAMengin! Head to the Music page to upload your tracks, create playlists, and embed them directly on your profile. We support Spotify integration, SoundCloud embeds, and direct uploads. Your music becomes part of your creative identity here!';
    } else if (lowerQuery.includes('shop') || lowerQuery.includes('merch')) {
      return 'Your merch shop is your direct line to your audience! You can add products with images, detailed descriptions, and pricing. Your fans can browse and purchase right from your profile without leaving the platform. It\'s a great way to build your brand and connect with supporters through physical goods!';
    } else if (lowerQuery.includes('connector') || lowerQuery.includes('youtube') || lowerQuery.includes('import')) {
      return 'Connectors are incredibly useful for aggregating your content! You can automatically import from platforms like YouTube, and you have full control over what appears in your feed. Set up rules to mute certain content, boost others, or create digest summaries. It\'s all about bringing your digital presence together in one place!';
    } else if (lowerQuery.includes('dark mode') || lowerQuery.includes('theme')) {
      return 'I see you\'re interested in customizing your visual experience! You can toggle between light and dark mode using the moon/sun icon in the navigation bar. Your preference is saved automatically, and you can switch anytime. The entire platform adapts beautifully to your chosen theme!';
    } else if (lowerQuery.includes('analytics')) {
      return 'Analytics help you understand your impact! Visit the Analytics page to see comprehensive metrics including views, likes, comments, follower growth, and revenue tracking. You can filter by time range, identify your top-performing content, and even export data for deeper analysis. Knowledge is power!';
    } else if (lowerQuery.includes('who are you') || lowerQuery.includes('what are you')) {
      return 'I\'m Dr. Eams, your dedicated AI assistant for DREAMengin! Think of me as your knowledgeable companion who knows every corner of this platform. I\'m here to help you succeed, whether you\'re creating content, building your audience, or exploring new features. I\'m always just a click away!';
    } else {
      return 'I\'m here to help with anything DREAMengin-related! You can ask me about creating posts, customizing your profile, setting up ads, managing lab projects, organizing your feed, exploring analytics, or any other platform features. What aspect of DREAMengin would you like to know more about?';
    }
  };

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 bg-gradient-to-r from-slate-700 to-slate-900 text-white p-4 rounded-full shadow-lg hover:shadow-xl transition-all hover:scale-110 z-50"
        aria-label="Open Dr. Eams AI Assistant"
      >
        <Bot className="w-6 h-6" />
      </button>
    );
  }

  return (
    <div className={`fixed bottom-6 right-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-2xl shadow-2xl z-50 transition-all ${
      isMinimized ? 'w-80 h-16' : 'w-96 h-[600px]'
    }`}>
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-slate-200 dark:border-slate-700 bg-gradient-to-r from-slate-700 to-slate-900 text-white rounded-t-2xl">
        <div className="flex items-center gap-2">
          <Bot className="w-5 h-5" />
          <span className="font-semibold">Dr. Eams</span>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsMinimized(!isMinimized)}
            className="p-1 hover:bg-white/20 rounded transition-colors"
            aria-label={isMinimized ? 'Maximize' : 'Minimize'}
          >
            {isMinimized ? <Maximize2 className="w-4 h-4" /> : <Minimize2 className="w-4 h-4" />}
          </button>
          <button
            onClick={() => setIsOpen(false)}
            className="p-1 hover:bg-white/20 rounded transition-colors"
            aria-label="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {!isMinimized && (
        <>
          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 h-[480px]">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[80%] p-3 rounded-lg ${
                    message.role === 'user'
                      ? 'bg-slate-700 text-white'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-slate-100'
                  }`}
                >
                  <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                  <span className="text-xs opacity-60 mt-1 block">
                    {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-slate-100 dark:bg-slate-800 p-3 rounded-lg">
                  <div className="flex gap-1">
                    <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                    <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                    <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div className="p-4 border-t border-slate-200 dark:border-slate-700">
            <div className="flex gap-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Ask me anything..."
                className="flex-1 px-4 py-2 border border-slate-300 dark:border-slate-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-500 dark:bg-slate-800 dark:text-white"
                disabled={isLoading}
              />
              <button
                onClick={handleSend}
                disabled={isLoading || !input.trim()}
                className="bg-slate-700 text-white p-2 rounded-lg hover:bg-slate-800 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                aria-label="Send message"
              >
                <Send className="w-5 h-5" />
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
