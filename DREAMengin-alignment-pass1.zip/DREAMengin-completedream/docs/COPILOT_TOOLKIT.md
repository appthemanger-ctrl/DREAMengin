# DREAMengin Repo Working Rules

Last updated: 2026-03-06

This file summarizes how automation or coding agents should work in this repo.

## Working rules

- Treat `README.md` as the master product spec.
- Preserve working code whenever possible.
- Rename and repurpose before rebuilding.
- Prefer canonical product language over legacy repo nicknames.
- Keep Node 24, pnpm, Next.js App Router, and Supabase assumptions stable unless there is a real need to change them.

## Canonical language

Use these names first:
- HomeDream
- EditProfileDream
- ViewProfile
- Dreams
- DreamShop
- DreamMarketplace
- DreamMenu
- DreamDM
- DreamAds
- Dr. Eams
- IDARi
- TheBoogieMan.Ai

## Alignment rule

When the repo contains unnamed or mixed-named systems, map them into the README spec before adding new top-level systems.
