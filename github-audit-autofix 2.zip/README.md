# GitHub Audit Autofix

This workflow attempts to automatically fix:

- TypeScript errors
- Duplicate imports
- Missing imports
- ESLint issues
- Unused imports
- Basic Supabase typing mismatches
- Common Next.js response typing issues

## Files

- `.github/workflows/audit-autofix.yml`
- `scripts/fix-audit.js`

## Usage

1. Copy these files into your repo.
2. Push to GitHub.
3. Run the workflow from the Actions tab.

The workflow will:
- run autofixes
- commit changes automatically
- push fixes back to the current branch
