// lib/ai/audit.ts
// Audit log writer for admin_audit_log table

import { createServerClient } from '@/lib/supabase/server';

interface WriteAuditLogInput {
  request_id: string;
  user_id: string;
  agent: string;
  ok: boolean;
  error_code?: string;
  latency_ms?: number;
  payload?: Record<string, unknown>;
}

/**
 * Write to admin_audit_log table
 */
export async function writeAuditLog(input: WriteAuditLogInput): Promise<void> {
  try {
    const supabase = await createServerClient();
    
    const { error } = await supabase
      .from('admin_audit_log')
      .insert({
        actor_user_id: input.user_id,
        action: `${input.agent}:${input.ok ? 'success' : 'error'}`,
        payload: {
          request_id: input.request_id,
          agent: input.agent,
          error_code: input.error_code,
          latency_ms: input.latency_ms,
          ...input.payload,
        },
      });
    
    if (error) {
      console.error('[audit] Failed to write audit log:', error);
      // Don't throw - audit failure shouldn't break the request
    }
  } catch (error) {
    console.error('[audit] Unexpected error writing audit log:', error);
  }
}
