'use client';

import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import { TouchBackend } from 'react-dnd-touch-backend';
import { useEffect, useMemo, useState } from 'react';

export default function DreamDndProvider({ children }: { children: React.ReactNode }) {
  const [isTouch, setIsTouch] = useState(false);

  useEffect(() => {
    const touch =
      typeof window !== 'undefined' && (('ontouchstart' in window) || (navigator.maxTouchPoints ?? 0) > 0);
    setIsTouch(Boolean(touch));
  }, []);

  const backend = useMemo(() => (isTouch ? TouchBackend : HTML5Backend), [isTouch]);
  const options = useMemo(() => (isTouch ? { enableMouseEvents: true } : undefined), [isTouch]);

  return (
    <DndProvider backend={backend} options={options}>
      {children}
    </DndProvider>
  );
}
