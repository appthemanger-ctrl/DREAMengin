-- Hotfix: ensure expected tables/columns exist and refresh PostgREST schema cache.
-- Safe to run multiple times.

DO $$
BEGIN
  -- Ensure app_posts exists
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_schema = 'public' AND table_name = 'app_posts'
  ) THEN
    CREATE TABLE public.app_posts (
      id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
      user_id uuid REFERENCES public.profiles(id) ON DELETE CASCADE,
      content text,
      media_json jsonb,
      visibility text DEFAULT 'followers',
      created_at timestamptz DEFAULT now()
    );

    CREATE INDEX IF NOT EXISTS idx_app_posts_user_ts ON public.app_posts(user_id, created_at DESC);
  END IF;

  -- Ensure music_releases.owner_id exists
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' AND table_name = 'music_releases' AND column_name = 'owner_id'
  ) THEN
    ALTER TABLE public.music_releases
      ADD COLUMN owner_id uuid REFERENCES public.profiles(id) ON DELETE CASCADE;
  END IF;
END
$$;

-- Ask PostgREST to reload its schema cache (fixes "... in the schema cache" errors)
SELECT pg_notify('pgrst', 'reload schema');
