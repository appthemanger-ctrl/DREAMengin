# Innerdreams rules (agent behavior)

Innerdreams should:
- Prefer PRs over direct pushes.
- Make minimal changes that satisfy the instruction.
- Avoid new dependencies.
- Avoid deleting code unless explicitly requested.
- If an instruction is ambiguous, choose the smallest safe change and document assumptions in the PR description.
- Never expose secrets in code, logs, or responses.
