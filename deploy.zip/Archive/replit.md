# Dreamengin - Social Media Hub

## Overview

Dreamengin is a social media hub application that serves as a "homepage for your homepages" - a unified dashboard where users can connect and manage all their social media, streaming, gaming, and creative platforms from one control room. The application features a sophisticated dark glassmorphic UI with floating window management, allowing users to open multiple platform modules simultaneously.

Key features include:
- 40+ platform integrations (social media, streaming, gaming, messaging, creative tools)
- Floating draggable/resizable window system for multi-tasking
- Focus mode for distraction-free work
- Cross-platform post composition
- Unified notification management
- Monetization-ready architecture

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight client-side routing)
- **State Management**: TanStack React Query for server state, custom `useAppState` hook with localStorage persistence for UI state
- **Styling**: Tailwind CSS with custom dark glassmorphic design system
- **UI Components**: shadcn/ui (Radix primitives) with extensive customization
- **Animations**: Framer Motion for page transitions and micro-interactions
- **Build Tool**: Vite with custom plugins for Replit integration

### Backend Architecture
- **Runtime**: Node.js with Express
- **Language**: TypeScript (ESM modules)
- **API Pattern**: RESTful endpoints under `/api/` prefix
- **Authentication**: Replit Auth with OpenID Connect (OIDC)
- **Session Management**: express-session with PostgreSQL session store (connect-pg-simple)

### Data Storage
- **Database**: PostgreSQL via Drizzle ORM
- **Schema Location**: `shared/schema.ts` and `shared/models/auth.ts`
- **Key Tables**: `users` (user profiles), `sessions` (auth sessions)
- **Client State**: localStorage for window positions, notification counts, and UI preferences

### Authentication Flow
- Replit Auth integration using OpenID Connect
- Session-based authentication with secure cookies
- User data upserted on login from Replit profile
- Protected routes use `isAuthenticated` middleware

### Window Management System
- Each platform module opens as a floating window
- Windows are draggable and resizable
- Z-index management for window stacking
- State persisted to localStorage with Zod validation

### Design System
- Custom dark glassmorphic theme with CSS variables
- Glass effects: 18-24px blur, semi-transparent backgrounds
- Color palette: Deep slate background (#020617), cyan accents, multi-layered gradients
- Typography: Inter font family (weights 300-900)
- Atmospheric elements: Animated starfield overlay, radial gradient backgrounds

## External Dependencies

### Database
- **PostgreSQL**: Primary database via `DATABASE_URL` environment variable
- **Drizzle ORM**: Type-safe database queries and schema management
- **connect-pg-simple**: Session storage in PostgreSQL

### Authentication
- **Replit Auth**: OIDC-based authentication
- **passport**: Authentication middleware
- **express-session**: Session management

### UI Libraries
- **Radix UI**: Accessible component primitives (dialog, dropdown, tabs, etc.)
- **Lucide React**: Icon library
- **react-icons**: Additional platform-specific icons (social media logos)
- **Framer Motion**: Animation library
- **class-variance-authority**: Component variant management
- **tailwind-merge**: Tailwind class merging utility

### Build & Development
- **Vite**: Frontend build tool with HMR
- **esbuild**: Server bundling for production
- **tsx**: TypeScript execution for development
- **drizzle-kit**: Database migration tooling

### Environment Variables Required
- `DATABASE_URL`: PostgreSQL connection string
- `SESSION_SECRET`: Express session secret
- `ISSUER_URL`: Replit OIDC issuer (defaults to https://replit.com/oidc)
- `REPL_ID`: Replit environment identifier