export function RuntimeBackground() {
  return (
    <>
      <div className="runtime-bg" aria-hidden="true" />
      <div className="starfield" aria-hidden="true" />
    </>
  );
}
