import { useState, useRef, useCallback, useEffect } from "react";
import { ModuleId } from "@shared/schema";

interface DockProps {
  notifications: Record<string, number>;
  onOpenModule: (id: ModuleId) => void;
  onToggleFocus: () => void;
  onMinimizeAll: () => void;
  onCloseAll: () => void;
}

const dockItems = [
  { id: "compose" as ModuleId, emoji: "📝", title: "Post to All", desc: "Create posts for all platforms" },
  { id: "notifications" as ModuleId, emoji: "🔔", title: "Notifications", desc: "View all your alerts" },
  { id: "feed" as ModuleId, emoji: "⚡", title: "Feed", desc: "See posts from friends you follow" },
  { id: "page" as ModuleId, emoji: "🪐", title: "Dream Canvas", desc: "Your creative workspace" },
  { id: "messages" as ModuleId, emoji: "💬", title: "Signals", desc: "DMs and mentions" },
  { id: "customize" as ModuleId, emoji: "🎨", title: "Customize", desc: "Personalize your dashboard" },
  { id: "settings" as ModuleId, emoji: "⚙️", title: "Settings", desc: "Account and preferences" },
];

const actionBtns = [
  { id: "clean", label: "Clean", shortLabel: "C", desc: "Toggle focus mode" },
  { id: "minimize", label: "Minimize", shortLabel: "M", desc: "Minimize all windows" },
  { id: "close", label: "Close", shortLabel: "X", desc: "Close all windows" },
];

export function Dock({
  notifications,
  onOpenModule,
  onToggleFocus,
  onMinimizeAll,
  onCloseAll,
}: DockProps) {
  const [isDesktopMode] = useState(false);
  const [hoveredItem, setHoveredItem] = useState<string | null>(null);
  const [selectedItem, setSelectedItem] = useState<string | null>(null);
  const [isTouchDevice, setIsTouchDevice] = useState(false);
  const lastTapTime = useRef<number>(0);
  const lastTapId = useRef<string | null>(null);

  useEffect(() => {
    const hasTouch = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
    setIsTouchDevice(hasTouch);
  }, []);

  // Auto-detect desktop mode: if viewport is wide (>1024px) on touch device, assume "Request Desktop Site"
  const isWideViewport = typeof window !== 'undefined' && window.innerWidth > 1024;
  const autoDesktopMode = isTouchDevice && isWideViewport;
  const useMobileMode = isTouchDevice && !isDesktopMode && !autoDesktopMode;

  const handleTap = useCallback((id: string, action: () => void) => {
    if (!useMobileMode) {
      action();
      return;
    }
    const now = Date.now();
    const isDoubleTap = lastTapId.current === id && (now - lastTapTime.current) < 400;
    
    if (isDoubleTap) {
      action();
      setSelectedItem(null);
      lastTapId.current = null;
    } else {
      setSelectedItem(id);
      lastTapTime.current = now;
      lastTapId.current = id;
    }
  }, [useMobileMode]);

  return (
    <div
      className="fixed left-0 right-0 bottom-0 z-[35] py-2 sm:py-2.5 px-2 sm:px-3.5 backdrop-blur-[22px] border-t safe-area-bottom"
      style={{
        background: "linear-gradient(to top, rgba(15,23,42,0.96), rgba(15,23,42,0.78))",
        borderColor: "rgba(148,163,184,0.4)",
      }}
    >
      <div
        className="w-full max-w-[880px] mx-auto flex items-center justify-between gap-1.5 sm:gap-2.5"
      >
        <div className="flex items-center gap-1 sm:gap-2 overflow-x-auto scrollbar-hide flex-1">
          {dockItems.map((item) => (
            <div key={item.id} className="relative flex-shrink-0">
              {(hoveredItem === item.id || selectedItem === item.id) && (
                <div 
                  className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2.5 py-1.5 rounded-lg whitespace-nowrap z-50 pointer-events-none"
                  style={{ 
                    background: useMobileMode ? "rgba(15,23,42,0.95)" : "rgba(2,6,23,0.9)", 
                    border: useMobileMode ? "1px solid rgba(148,163,184,0.3)" : "1px solid rgba(6,182,212,0.3)",
                    boxShadow: useMobileMode ? "0 4px 12px rgba(0,0,0,0.4)" : "0 4px 20px rgba(6,182,212,0.15)"
                  }}
                >
                  <div className="text-[10px] font-semibold" style={{ color: useMobileMode ? "var(--text-primary)" : "#22d3ee" }}>{item.title}</div>
                  <div className="text-[9px] text-secondary-glass">{item.desc}</div>
                  {useMobileMode && <div className="text-[8px] text-cyan-400/70 mt-1">Tap again to open</div>}
                </div>
              )}
              <button
                className="dock-btn"
                onMouseEnter={() => !useMobileMode && setHoveredItem(item.id)}
                onMouseLeave={() => !useMobileMode && setHoveredItem(null)}
                onTouchEnd={(e) => {
                  if (useMobileMode) {
                    e.preventDefault();
                    handleTap(item.id, () => onOpenModule(item.id));
                  }
                }}
                onClick={(e) => {
                  if (useMobileMode && e.detail === 0) return;
                  if (!useMobileMode) onOpenModule(item.id);
                }}
                data-testid={`dock-btn-${item.id}`}
              >
                <span>{item.emoji}</span>
                {(notifications[item.id] || 0) > 0 && (
                  <div className="dock-badge" data-testid={`dock-badge-${item.id}`}>
                    {notifications[item.id]}
                  </div>
                )}
              </button>
            </div>
          ))}
        </div>

        <div className="flex items-center gap-1 sm:gap-2 flex-shrink-0">
          {actionBtns.map((btn) => {
            const action = btn.id === "clean" ? onToggleFocus : btn.id === "minimize" ? onMinimizeAll : onCloseAll;
            return (
              <div key={btn.id} className="relative">
                {(hoveredItem === btn.id || selectedItem === btn.id) && (
                  <div 
                    className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2.5 py-1.5 rounded-lg whitespace-nowrap z-50 pointer-events-none"
                    style={{ 
                      background: useMobileMode ? "rgba(15,23,42,0.95)" : "rgba(2,6,23,0.9)", 
                      border: useMobileMode ? "1px solid rgba(148,163,184,0.3)" : "1px solid rgba(6,182,212,0.3)",
                      boxShadow: useMobileMode ? "0 4px 12px rgba(0,0,0,0.4)" : "0 4px 20px rgba(6,182,212,0.15)"
                    }}
                  >
                    <div className="text-[10px] font-semibold" style={{ color: useMobileMode ? "var(--text-primary)" : "#22d3ee" }}>{btn.label}</div>
                    <div className="text-[9px] text-secondary-glass">{btn.desc}</div>
                    {useMobileMode && <div className="text-[8px] text-cyan-400/70 mt-1">Tap again to activate</div>}
                  </div>
                )}
                <button
                  className="pill-btn text-xs sm:text-sm px-2 sm:px-3"
                  onMouseEnter={() => !useMobileMode && setHoveredItem(btn.id)}
                  onMouseLeave={() => !useMobileMode && setHoveredItem(null)}
                  onTouchEnd={(e) => {
                    if (useMobileMode) {
                      e.preventDefault();
                      handleTap(btn.id, action);
                    }
                  }}
                  onClick={(e) => {
                    if (useMobileMode && e.detail === 0) return;
                    if (!useMobileMode) action();
                  }}
                  data-testid={`button-${btn.id === "close" ? "close-all" : btn.id}`}
                >
                  <span className="hidden sm:inline">{btn.label}</span>
                  <span className="sm:hidden">{btn.shortLabel}</span>
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
