import { FloatingModule } from "./FloatingModule";
import { ModuleId, WindowState, moduleIds } from "@shared/schema";

interface ModuleLayerProps {
  windows: Record<string, WindowState>;
  focusMode: boolean;
  onClose: (id: ModuleId) => void;
  onMinimize: (id: ModuleId) => void;
  onBringToFront: (id: ModuleId) => void;
  onUpdatePosition: (id: ModuleId, x: number, y: number) => void;
  onUpdateSize: (id: ModuleId, w: number, h: number) => void;
}

export function ModuleLayer({
  windows,
  focusMode,
  onClose,
  onMinimize,
  onBringToFront,
  onUpdatePosition,
  onUpdateSize,
}: ModuleLayerProps) {
  if (focusMode) {
    return null;
  }

  const openModules = moduleIds.filter((id) => windows[id]?.open);

  return (
    <>
      {openModules.map((id) => (
        <FloatingModule
          key={id}
          id={id}
          windowState={windows[id]}
          onClose={() => onClose(id)}
          onMinimize={() => onMinimize(id)}
          onBringToFront={() => onBringToFront(id)}
          onUpdatePosition={(x, y) => onUpdatePosition(id, x, y)}
          onUpdateSize={(w, h) => onUpdateSize(id, w, h)}
        />
      ))}
    </>
  );
}
