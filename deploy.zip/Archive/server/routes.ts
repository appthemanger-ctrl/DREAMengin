import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, registerAuthRoutes } from "./replit_integrations/auth";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  await setupAuth(app);
  registerAuthRoutes(app);

  app.post("/api/admin-login", (req, res) => {
    const { key } = req.body;
    const adminKey = process.env.ADMIN_KEY;
    
    if (!adminKey) {
      return res.status(500).json({ error: "Admin key not configured" });
    }
    
    if (key === adminKey) {
      (req.session as any).isAdmin = true;
      (req.session as any).user = {
        id: "admin",
        username: "Admin",
        firstName: "Admin",
        lastName: "User",
        profileImageUrl: null,
      };
      return res.json({ success: true });
    }
    
    return res.status(401).json({ error: "Invalid admin key" });
  });

  app.get("/api/auth/user", (req, res) => {
    if ((req.session as any)?.isAdmin && (req.session as any)?.user) {
      return res.json((req.session as any).user);
    }
    if ((req as any).user) {
      return res.json((req as any).user);
    }
    return res.status(401).json({ error: "Not authenticated" });
  });

  app.post("/api/delete-account", async (req, res) => {
    const userId = (req as any).user?.id || (req.session as any)?.user?.id;
    if (userId && userId !== "admin") {
      try {
        await storage.deleteUser(userId);
      } catch (e) {
        console.log("User deletion skipped or failed:", e);
      }
    }
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ error: "Failed to destroy session" });
      }
      res.clearCookie("connect.sid");
      return res.json({ success: true, message: "Account deleted and all data removed" });
    });
  });

  return httpServer;
}
