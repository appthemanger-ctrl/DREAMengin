# Design Guidelines: Dreamengin.com Social Media Hub Dashboard

## Design Approach
**System**: Custom Neon-Ice Glassmorphic Design  
**Justification**: Social media hub dashboard requiring sophisticated window management, content-rich feeds, and atmospheric depth. Emphasizes premium tech aesthetic with cool, electric color palette and spatial layering.

## Core Design Elements

### A. Color System
**Foundation**:
- Background Base: #0a1628 (deep navy)
- Background Secondary: #020817 (near-black navy)
- Glass Primary: rgba(10,22,40,0.85) - 85% opacity
- Glass Soft: rgba(10,22,40,0.75) - 75% opacity

**Borders & Outlines**:
- Border Primary: rgba(34,211,238,0.35) - cyan
- Border Subtle: rgba(20,184,166,0.25) - teal
- Border Inactive: rgba(148,163,184,0.20)

**Typography**:
- Text Primary: rgba(248,250,252,0.98)
- Text Secondary: rgba(203,213,225,0.88)
- Text Muted: rgba(148,163,184,0.75)

**Accent Colors**:
- Primary Accent: #06b6d4 - electric cyan
- Secondary Accent: #14b8a6 - teal
- Tertiary Accent: #10b981 - emerald
- Interactive Hover: rgba(6,182,212,0.90)
- Success: #10b981 - emerald
- Alert: #ef4444 - red (minimal use)

**Atmospheric Layers**:
- Radial gradient overlays: cyan (top-left), teal (center), emerald (bottom-right) at 15-25% opacity
- Animated starfield: white/cyan dots, 0.4-0.6 opacity, slow drift animation
- Blur intensity: 20-28px for glass surfaces

### B. Typography
**Font Family**: Inter (weights 300, 400, 600, 900)

**Hierarchy**:
- Dashboard title: 28px, weight 900, tracking -0.03em
- Window headers: 16px, weight 900, tracking -0.02em
- Post author names: 14px, weight 600
- Status labels: 10px, weight 600, tracking 0.20em, uppercase
- Feed content: 14px, weight 400, line-height 1.6
- Metadata/timestamps: 12px, weight 400, muted color
- Button text: 13px, weight 600

### C. Layout System
**Spacing Units**: Tailwind 2, 3, 4, 6, 8, 12, 16, 20, 24

**Dashboard Grid**:
- Desktop: 2.5fr (feed/content) + 1.2fr (sidebar), 20px gap
- Max-width: 1280px, centered
- Mobile: Single column, full-width

**Feed Layout**:
- Card spacing: 16px vertical gap
- Content padding: 16-20px
- Max-width for readability: 680px for text-heavy posts

**Window System**:
- Draggable floating windows with z-index layering (100-150 range)
- Minimum window size: 320px x 400px
- Snap-to-grid on desktop (20px intervals)

### D. Component Library

**Glass Containers**:
- Main Feed: 24px border-radius, 24px blur, 1px cyan border
- Sidebar Modules: 20px border-radius, 20px blur, subtle teal border
- Post Cards: 18px border-radius, shadow (0 8px 32px rgba(0,0,0,0.4))
- All glass surfaces: backdrop-filter blur with semi-transparent navy background

**Floating Windows**:
- Header: 28px height, gradient from glass to darker, drag handle
- Title: Emoji 20px + text 16px weight 900
- Controls: 32px circles (minimize, maximize, close), cyan icons 14px
- Body: Scrollable, custom cyan scrollbar (6px width)
- Resize handle: 16px square, bottom-right corner, nwse-resize cursor
- Border: 1.5px cyan at 35% opacity
- Shadow: 0 24px 64px rgba(6,182,212,0.15)
- Open animation: scale(0.94) + opacity(0) → scale(1) + opacity(1), 0.2s

**Social Media Posts**:
- Avatar: 40px circle, 2px cyan border for verified users
- Author row: Avatar + name (14px weight 600) + timestamp (12px muted)
- Content: 14px text, max 3 lines preview with "Read more" link in cyan
- Actions bar: Like/Comment/Share icons 18px, counts 13px, teal color
- Interaction states: Cyan glow on hover (0 0 12px rgba(6,182,212,0.4))

**Navigation & Status Bar**:
- Top bar: Fixed, full-width, glass background with heavy blur
- Logo: 24px, weight 900, cyan accent color
- Search: 360px width, 16px border-radius, glass background, cyan border on focus
- User avatar: 36px circle, notification badge (8px red dot, top-right)
- Icons: 20px, teal color, cyan on hover

**Sidebar Modules**:
- Trending Topics: List of 5-7 items, 14px text, emerald highlight on hover
- Suggested Users: Avatar 32px + name + follow button
- Activity Feed: Icon 16px + text 13px + timestamp, 12px vertical spacing

**Buttons**:
- Primary: Linear gradient cyan to teal, 16px border-radius, 12-16px padding, cyan glow shadow (0 4px 16px rgba(6,182,212,0.3))
- Secondary: Glass background, cyan border, teal text
- Ghost: Transparent, cyan text, cyan border on hover
- All buttons: 13px weight 600, 0.15s transition

**Form Elements**:
- Input fields: 16px border-radius, 12px padding, glass background, cyan border on focus
- Textarea: Same as input, min-height 120px
- Select dropdowns: Glass background, cyan accent

**Badges & Pills**:
- Notification badges: 18px min-width, rounded-full, gradient cyan-teal, white text weight 900
- Status pills: 999px border-radius, 8-12px padding, uppercase 10px tracking 0.18em

### E. Interactions

**Hover States**:
- Posts: Lift (translateY(-2px)) + cyan border glow + enhanced shadow
- Buttons: Lift (translateY(-1px)) + brightness increase (110%) + stronger glow
- Window headers: Cursor grab, subtle cyan glow on dragover
- Links: Cyan color + underline offset 2px

**Active States**:
- Buttons: Scale(0.98) + reduced shadow
- Liked posts: Filled heart icon, emerald color
- Bookmarked items: Filled bookmark, teal color

**Transitions**: 0.15s ease-out for all interactions

**Loading States**:
- Skeleton screens: Shimmer animation, glass background with cyan highlights
- Progress bars: Cyan gradient fill

### F. Special Features

**Starfield Background**:
- Canvas-based or CSS animation
- 100-150 stars, varying sizes (1-3px)
- Colors: white (60%), cyan (30%), teal (10%)
- Slow parallax drift on scroll (0.3x speed)
- Opacity pulse: 0.3-0.8, 3-5s duration per star

**Window Management**:
- Click window to bring to front (z-index increment)
- Double-click header to maximize/restore
- Minimize slides to bottom-left dock
- Windows remember position per session

**Focus Mode**:
- Toggle button in top-right status bar
- Dims sidebar and floating windows (40% opacity)
- Enlarges feed area
- Smooth 0.3s opacity transition

**Notification System**:
- Toast notifications: Top-right, 360px width, glass background, 4s auto-dismiss
- Slide-in animation from right (translateX(400px) → 0)
- Notification center: Floating window, chronological list

### G. Images & Media

**Hero Section**: None - dashboard interface opens directly to feed

**User Content**:
- Post images: 16px border-radius, max-width 100%, lazy loading
- Image galleries: 2x2 grid for multiple images, 8px gap
- Video thumbnails: Play button overlay (60px circle, cyan with 40% opacity)

**Avatars**:
- Profile photos throughout interface
- Verified badge: Cyan checkmark icon overlay, 14px, bottom-right
- Online status: 10px emerald dot, border-right of avatar

**Background Elements**:
- Use abstract tech patterns or circuit board textures at very low opacity (5-10%) beneath glass surfaces
- Optional geometric line patterns connecting window corners

### H. Layout Constraints

**Viewport Management**:
- Full-height application (100vh)
- Fixed status bar: Top 56px, blur backdrop
- Scrollable feed: Between status bar and bottom (if needed)
- Floating windows: Constrained to viewport bounds with 20px padding

**Responsive Breakpoints**:
- Desktop (1280px+): Full grid layout, multiple floating windows
- Tablet (768-1279px): Simplified grid, max 2 floating windows
- Mobile (<768px): Single column, floating windows become full-screen modals

**Accessibility**:
- Minimum contrast ratio 7:1 for primary text
- Focus indicators: 2px cyan outline with 2px offset
- Keyboard navigation: Tab order follows visual hierarchy
- Reduced motion: Disable starfield and lift animations
- Screen reader labels for all interactive elements