# Innerdreams (agent) – setup

## What Innerdreams actually is
Innerdreams is a *publicly accessible admin page* + a *server-side Pages Function*.

- **Admin UI (browser):** usable from any computer.
- **Agent brain (server-side):** holds secrets (GitHub token / OpenAI key) and opens PRs.

Browsers cannot safely store repo-write credentials. So the “do work” part must run server-side.

## URLs
- Admin page: `/innerdreams-admin.html`
- Health check: `/health`
- Agent endpoint: `GET/POST /api/innerdreams`

## Required Cloudflare env vars
In Cloudflare Pages → Settings → Environment variables:

- `INNERDREAMS_PASSWORD`  (your admin access code)
- `GITHUB_TOKEN`          (fine-grained token with repo write + PR)
- `GITHUB_OWNER`          (e.g. appthemanger-ctrl)
- `GITHUB_REPO`           (e.g. Newdreams)
- `OPENAI_API_KEY`

Optional:
- `OPENAI_MODEL` (defaults to gpt-4.1-mini)

## Optional (recommended): KV for pause/resume persistence
If you bind a KV namespace named `INNERDREAMS_KV`, the pause/resume state and autopilot rate-limit will persist reliably.

Without KV, the state may reset if Cloudflare moves the function between isolates.

## “Autopilot”
Pages Functions only run when called. There is no always-on background loop.

Autopilot here means: **you click “Run autopilot now”** (or you ping the endpoint from a cron service),
and Innerdreams opens a PR containing `INNERDREAMS_REPORT.md`.

## Security
- Do NOT hardcode GitHub tokens or OpenAI keys in client code.
- The admin page sends your password to the server over HTTPS, and the server checks it against `INNERDREAMS_PASSWORD`.
