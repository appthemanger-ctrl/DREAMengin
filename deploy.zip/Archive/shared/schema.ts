import { z } from "zod";

export * from "./models/auth";

export const moduleIds = [
  "feed", "page", "messages", "store", "settings", "vault", "customize", "compose", "notifications",
  "instagram", "tiktok", "x", "messenger", "youtube", "spotify",
  "netflix", "disney", "hulu", "crunchyroll", "prime", "hbomax", "peacock", "paramount",
  "roblox", "twitch", "discord", "snapchat", "linkedin", "pinterest",
  "threads", "reddit", "github", "notion", "figma", "dribbble",
  "whatsapp", "telegram", "signal", "bereal", "clubhouse",
  "steam", "xbox", "playstation", "epicgames", "minecraft"
] as const;

export type ModuleId = typeof moduleIds[number];

export const windowStateSchema = z.object({
  open: z.boolean(),
  x: z.number(),
  y: z.number(),
  w: z.number(),
  h: z.number(),
  z: z.number(),
});

export type WindowState = z.infer<typeof windowStateSchema>;

export const notificationsSchema = z.record(z.string(), z.number());
export type Notifications = z.infer<typeof notificationsSchema>;

export const dropItemSchema = z.object({
  id: z.string(),
  text: z.string(),
  meta: z.string(),
});
export type DropItem = z.infer<typeof dropItemSchema>;

export const appStateSchema = z.object({
  focus: z.boolean(),
  notifications: notificationsSchema,
  drops: z.array(dropItemSchema),
  windows: z.record(z.string(), windowStateSchema),
});

export type AppState = z.infer<typeof appStateSchema>;

export interface ModuleInfo {
  name: string;
  emoji: string;
}

export interface SocialLink {
  name: string;
  handle: string;
  url: string;
  emoji: string;
  hint: string;
}

export interface StreamingLink {
  name: string;
  url: string;
  emoji: string;
  hint: string;
}

export const MODULES: Record<ModuleId, ModuleInfo> = {
  feed: { name: "FEED", emoji: "⚡" },
  page: { name: "DREAM CANVAS", emoji: "🪐" },
  messages: { name: "SIGNALS", emoji: "💬" },
  store: { name: "STORE", emoji: "🛒" },
  settings: { name: "SETTINGS", emoji: "⚙️" },
  vault: { name: "VAULT", emoji: "🔒" },
  customize: { name: "CUSTOMIZE", emoji: "🎨" },
  compose: { name: "POST TO ALL", emoji: "📝" },
  notifications: { name: "NOTIFICATIONS", emoji: "🔔" },
  instagram: { name: "INSTAGRAM", emoji: "📸" },
  tiktok: { name: "TIKTOK", emoji: "🎵" },
  x: { name: "X / TWITTER", emoji: "🐦" },
  messenger: { name: "MESSENGER", emoji: "💬" },
  youtube: { name: "YOUTUBE", emoji: "▶️" },
  spotify: { name: "SPOTIFY", emoji: "🎧" },
  netflix: { name: "NETFLIX", emoji: "🟥" },
  disney: { name: "DISNEY+", emoji: "🌌" },
  hulu: { name: "HULU", emoji: "🟩" },
  crunchyroll: { name: "CRUNCHYROLL", emoji: "🟧" },
  prime: { name: "PRIME VIDEO", emoji: "📦" },
  hbomax: { name: "MAX", emoji: "🎬" },
  peacock: { name: "PEACOCK", emoji: "🦚" },
  paramount: { name: "PARAMOUNT+", emoji: "⭐" },
  roblox: { name: "ROBLOX", emoji: "🎮" },
  twitch: { name: "TWITCH", emoji: "📺" },
  discord: { name: "DISCORD", emoji: "🎙️" },
  snapchat: { name: "SNAPCHAT", emoji: "👻" },
  linkedin: { name: "LINKEDIN", emoji: "💼" },
  pinterest: { name: "PINTEREST", emoji: "📌" },
  threads: { name: "THREADS", emoji: "🧵" },
  reddit: { name: "REDDIT", emoji: "🤖" },
  github: { name: "GITHUB", emoji: "🐙" },
  notion: { name: "NOTION", emoji: "📝" },
  figma: { name: "FIGMA", emoji: "🎨" },
  dribbble: { name: "DRIBBBLE", emoji: "🏀" },
  whatsapp: { name: "WHATSAPP", emoji: "📱" },
  telegram: { name: "TELEGRAM", emoji: "✈️" },
  signal: { name: "SIGNAL", emoji: "🔐" },
  bereal: { name: "BEREAL", emoji: "📷" },
  clubhouse: { name: "CLUBHOUSE", emoji: "🎤" },
  steam: { name: "STEAM", emoji: "🎮" },
  xbox: { name: "XBOX", emoji: "🎯" },
  playstation: { name: "PLAYSTATION", emoji: "🕹️" },
  epicgames: { name: "EPIC GAMES", emoji: "🏰" },
  minecraft: { name: "MINECRAFT", emoji: "⛏️" },
};

export const SOCIAL_LINKS: Record<string, SocialLink> = {
  instagram: { name: "Instagram", handle: "@yourhandle", url: "https://instagram.com/yourhandle", emoji: "📸", hint: "Main visual grid + stories." },
  tiktok: { name: "TikTok", handle: "@yourhandle", url: "https://www.tiktok.com/@yourhandle", emoji: "🎵", hint: "Short-form hits and trends." },
  x: { name: "X / Twitter", handle: "@yourhandle", url: "https://x.com/yourhandle", emoji: "🐦", hint: "Threads, takes, and live signal." },
  messenger: { name: "Messenger", handle: "Your Name", url: "https://m.me/yourusername", emoji: "💬", hint: "DM hub tied to your FB graph." },
  youtube: { name: "YouTube", handle: "Your Channel", url: "https://www.youtube.com/@yourchannel", emoji: "▶️", hint: "Episodes, clips, and live sets." },
  spotify: { name: "Spotify", handle: "Your Artist", url: "https://open.spotify.com/artist/yourid", emoji: "🎧", hint: "Music, pods, and playlists." },
  snapchat: { name: "Snapchat", handle: "@yourhandle", url: "https://snapchat.com/add/yourhandle", emoji: "👻", hint: "Snaps, stories, and spotlight." },
  linkedin: { name: "LinkedIn", handle: "Your Profile", url: "https://linkedin.com/in/yourprofile", emoji: "💼", hint: "Professional network and content." },
  pinterest: { name: "Pinterest", handle: "@yourhandle", url: "https://pinterest.com/yourhandle", emoji: "📌", hint: "Boards, pins, and inspiration." },
  threads: { name: "Threads", handle: "@yourhandle", url: "https://threads.net/@yourhandle", emoji: "🧵", hint: "Text-based conversations." },
  reddit: { name: "Reddit", handle: "u/yourhandle", url: "https://reddit.com/user/yourhandle", emoji: "🤖", hint: "Communities and discussions." },
  github: { name: "GitHub", handle: "@yourhandle", url: "https://github.com/yourhandle", emoji: "🐙", hint: "Code, projects, and repos." },
  notion: { name: "Notion", handle: "Your Workspace", url: "https://notion.so", emoji: "📝", hint: "Notes, docs, and wikis." },
};

export const STREAMING_LINKS: Record<string, StreamingLink> = {
  netflix: { name: "Netflix", url: "https://www.netflix.com", emoji: "🟥", hint: "Series stack and films." },
  disney: { name: "Disney+", url: "https://www.disneyplus.com", emoji: "🌌", hint: "Marvel, Star Wars, and more." },
  hulu: { name: "Hulu", url: "https://www.hulu.com", emoji: "🟩", hint: "Shows, next-day TV, originals." },
  crunchyroll: { name: "Crunchyroll", url: "https://www.crunchyroll.com", emoji: "🟧", hint: "Anime lane, simulcasts." },
  prime: { name: "Prime Video", url: "https://www.amazon.com/Prime-Video", emoji: "📦", hint: "Films, shows, and originals." },
  hbomax: { name: "Max", url: "https://www.max.com", emoji: "🎬", hint: "HBO content and more." },
  peacock: { name: "Peacock", url: "https://www.peacocktv.com", emoji: "🦚", hint: "NBC content and originals." },
  paramount: { name: "Paramount+", url: "https://www.paramountplus.com", emoji: "⭐", hint: "CBS and Paramount content." },
};

export const GAMING_LINKS: Record<string, StreamingLink> = {
  roblox: { name: "Roblox", url: "https://www.roblox.com", emoji: "🎮", hint: "Games, experiences, and creation." },
  twitch: { name: "Twitch", url: "https://www.twitch.tv", emoji: "📺", hint: "Live streams and gaming." },
  discord: { name: "Discord", url: "https://discord.com", emoji: "🎙️", hint: "Servers, voice, and community." },
  steam: { name: "Steam", url: "https://store.steampowered.com", emoji: "🎮", hint: "PC games and community." },
  xbox: { name: "Xbox", url: "https://www.xbox.com", emoji: "🎯", hint: "Games and Game Pass." },
  playstation: { name: "PlayStation", url: "https://www.playstation.com", emoji: "🕹️", hint: "Console gaming and PS+." },
  epicgames: { name: "Epic Games", url: "https://www.epicgames.com", emoji: "🏰", hint: "Fortnite and free games." },
  minecraft: { name: "Minecraft", url: "https://www.minecraft.net", emoji: "⛏️", hint: "Build and explore." },
};

export const MESSAGING_LINKS: Record<string, SocialLink> = {
  whatsapp: { name: "WhatsApp", handle: "Your Number", url: "https://web.whatsapp.com", emoji: "📱", hint: "Messaging and calls." },
  telegram: { name: "Telegram", handle: "@yourhandle", url: "https://telegram.org", emoji: "✈️", hint: "Fast and secure messaging." },
  signal: { name: "Signal", handle: "Your Number", url: "https://signal.org", emoji: "🔐", hint: "Private messaging." },
};

export const CREATIVE_LINKS: Record<string, SocialLink> = {
  figma: { name: "Figma", handle: "@yourhandle", url: "https://figma.com", emoji: "🎨", hint: "Design and prototyping." },
  dribbble: { name: "Dribbble", handle: "@yourhandle", url: "https://dribbble.com", emoji: "🏀", hint: "Design showcase." },
  bereal: { name: "BeReal", handle: "@yourhandle", url: "https://bereal.com", emoji: "📷", hint: "Authentic moments." },
  clubhouse: { name: "Clubhouse", handle: "@yourhandle", url: "https://clubhouse.com", emoji: "🎤", hint: "Audio conversations." },
};

export const DEFAULT_STATE: AppState = {
  focus: false,
  notifications: {
    feed: 0, page: 0, messages: 2, store: 0, settings: 0, vault: 1, customize: 0, compose: 0, notifications: 5,
    instagram: 0, tiktok: 0, x: 0, messenger: 0, youtube: 0, spotify: 0,
    roblox: 3, twitch: 0, discord: 5, snapchat: 0, linkedin: 0, pinterest: 0,
    threads: 0, reddit: 0, github: 0, notion: 0, figma: 0, dribbble: 0,
    whatsapp: 0, telegram: 0, signal: 0, bereal: 0, clubhouse: 0,
    steam: 0, xbox: 0, playstation: 0, epicgames: 0, minecraft: 0,
    netflix: 0, disney: 0, hulu: 0, crunchyroll: 0, prime: 0, hbomax: 0, peacock: 0, paramount: 0
  },
  drops: [
    { id: "CCC-001", text: "Connected Chaos — New Mix", meta: "Now Playing • 3:42" },
    { id: "CCC-002", text: "Q1 Budget Approved", meta: "Ledger • $1,200 verified" },
    { id: "CCC-003", text: "New Roblox Experience Live", meta: "Gaming • 1.2K plays" },
    { id: "CCC-004", text: "Discord Server Growing", meta: "Community • 500+ members" },
  ],
  windows: {
    feed: { open: false, x: 60, y: 110, w: 420, h: 520, z: 10 },
    page: { open: false, x: 520, y: 130, w: 420, h: 520, z: 11 },
    messages: { open: false, x: 120, y: 180, w: 380, h: 480, z: 12 },
    store: { open: false, x: 560, y: 210, w: 380, h: 480, z: 13 },
    settings: { open: false, x: 230, y: 140, w: 420, h: 520, z: 14 },
    vault: { open: false, x: 300, y: 160, w: 420, h: 520, z: 15 },
    customize: { open: false, x: 180, y: 120, w: 450, h: 550, z: 16 },
    compose: { open: false, x: 200, y: 100, w: 480, h: 520, z: 17 },
    notifications: { open: false, x: 600, y: 100, w: 380, h: 500, z: 18 },
    instagram: { open: false, x: 360, y: 120, w: 360, h: 320, z: 20 },
    tiktok: { open: false, x: 390, y: 150, w: 360, h: 320, z: 21 },
    x: { open: false, x: 420, y: 180, w: 360, h: 320, z: 22 },
    messenger: { open: false, x: 450, y: 210, w: 360, h: 320, z: 23 },
    youtube: { open: false, x: 480, y: 240, w: 380, h: 340, z: 24 },
    spotify: { open: false, x: 510, y: 270, w: 380, h: 340, z: 25 },
    netflix: { open: false, x: 140, y: 140, w: 360, h: 320, z: 30 },
    disney: { open: false, x: 170, y: 170, w: 360, h: 320, z: 31 },
    hulu: { open: false, x: 200, y: 200, w: 360, h: 320, z: 32 },
    crunchyroll: { open: false, x: 230, y: 230, w: 360, h: 320, z: 33 },
    prime: { open: false, x: 260, y: 260, w: 360, h: 320, z: 34 },
    hbomax: { open: false, x: 290, y: 290, w: 360, h: 320, z: 35 },
    peacock: { open: false, x: 320, y: 320, w: 360, h: 320, z: 36 },
    paramount: { open: false, x: 350, y: 350, w: 360, h: 320, z: 37 },
    roblox: { open: false, x: 260, y: 140, w: 380, h: 360, z: 40 },
    twitch: { open: false, x: 290, y: 170, w: 380, h: 360, z: 41 },
    discord: { open: false, x: 320, y: 200, w: 380, h: 360, z: 42 },
    steam: { open: false, x: 350, y: 230, w: 380, h: 360, z: 43 },
    xbox: { open: false, x: 380, y: 260, w: 380, h: 360, z: 44 },
    playstation: { open: false, x: 410, y: 290, w: 380, h: 360, z: 45 },
    epicgames: { open: false, x: 440, y: 320, w: 380, h: 360, z: 46 },
    minecraft: { open: false, x: 470, y: 350, w: 380, h: 360, z: 47 },
    snapchat: { open: false, x: 350, y: 130, w: 340, h: 300, z: 50 },
    linkedin: { open: false, x: 380, y: 160, w: 340, h: 300, z: 51 },
    pinterest: { open: false, x: 410, y: 190, w: 340, h: 300, z: 52 },
    threads: { open: false, x: 440, y: 220, w: 340, h: 300, z: 53 },
    reddit: { open: false, x: 470, y: 250, w: 340, h: 300, z: 54 },
    github: { open: false, x: 500, y: 280, w: 340, h: 300, z: 55 },
    notion: { open: false, x: 530, y: 310, w: 340, h: 300, z: 56 },
    figma: { open: false, x: 560, y: 340, w: 340, h: 300, z: 57 },
    dribbble: { open: false, x: 200, y: 150, w: 340, h: 300, z: 58 },
    whatsapp: { open: false, x: 230, y: 180, w: 340, h: 300, z: 59 },
    telegram: { open: false, x: 260, y: 210, w: 340, h: 300, z: 60 },
    signal: { open: false, x: 290, y: 240, w: 340, h: 300, z: 61 },
    bereal: { open: false, x: 320, y: 270, w: 340, h: 300, z: 62 },
    clubhouse: { open: false, x: 350, y: 300, w: 340, h: 300, z: 63 },
  },
};

