export type WidgetType =
  | "daydreams"
  | "profile"
  | "music"
  | "video"
  | "gallery"
  | "link"
  | "embed"
  | "custom";

export type WidgetInstance = {
  id: string;
  owner_id: string;
  title: string;
  widget_type: WidgetType | string;
  config: Record<string, unknown>;
  is_enabled: boolean;
  created_at?: string;
  updated_at?: string;
};
